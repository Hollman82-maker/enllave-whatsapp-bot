const venom = require('venom-bot');
const express = require('express');
const fs = require('fs');
const app = express();
const PORT = process.env.PORT || 3000;

const menuData = require('./menu.json');
const LOG_FILE = './logs.json';

let seenUsers = new Set();

function logInteraction(user, message, response) {
    const log = {
        timestamp: new Date().toISOString(),
        user,
        message,
        response
    };
    let logs = [];
    if (fs.existsSync(LOG_FILE)) {
        logs = JSON.parse(fs.readFileSync(LOG_FILE, 'utf-8'));
    }
    logs.push(log);
    fs.writeFileSync(LOG_FILE, JSON.stringify(logs, null, 2));
}

venom
  .create({ session: 'enllave-session' })
  .then((client) => start(client))
  .catch((error) => console.error(error));

function start(client) {
    client.onMessage(async (message) => {
        const number = message.from;
        const texto = message.body.trim();

        let response = "";

        if (texto === "0") {
            seenUsers.delete(number);
            response = "🔄 Reiniciando menú...\n\n" + menuData.menu;
        } else if (!seenUsers.has(number)) {
            seenUsers.add(number);
            response = menuData.menu;
        } else if (menuData.respuestas[texto]) {
            response = menuData.respuestas[texto];
        } else {
            response = "❌ Opción no válida. Escribe un número del menú o 0 para reiniciar.";
        }

        await client.sendText(number, response);
        logInteraction(number, texto, response);
    });
}

app.get('/', (req, res) => {
  res.send('Bot de Enllave corriendo...');
});

app.listen(PORT, () => {
  console.log(`Servidor Express corriendo en puerto ${PORT}`);
});